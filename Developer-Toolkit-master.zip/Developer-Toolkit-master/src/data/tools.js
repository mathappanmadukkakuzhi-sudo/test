export const tools = [
  {
    id: 'svg-animation',
    name: 'SVG Animation Creator',
    description: 'Design, animate, timeline, and export production-ready animated SVGs with keyframes.',
    category: 'CSS Tools',
    path: '/svg-animation',
    icon: 'Sparkles'
  },
  {
    id: 'color-filter',
    name: 'Color Filter Generator',
    description: 'Convert monochrome icons into any target color using CSS filters.',
    category: 'CSS Tools',
    path: '/color-filter',
    icon: 'Palette'
  },
  {
    id: 'icon-creator',
    name: 'Icon Creator',
    description: 'Generate square text-based icons easily.',
    category: 'Icon Tools',
    path: '/icon-creator',
    icon: 'Image'
  },
  {
    id: 'code-diff-checker',
    name: 'Code Diff Checker',
    description: 'Compare two blocks of code to see what was added, removed, or changed.',
    category: 'Utilities',
    path: '/code-diff-checker',
    icon: 'GitCompare'
  },
  {
    id: 'file-converter',
    name: 'File Format Converter',
    description: 'Convert files between popular formats quickly and securely.',
    category: 'Utilities',
    path: '/file-converter',
    icon: 'FileDown'
  },
  {
    id: 'box-shadow',
    name: 'Box Shadow Generator',
    description: 'Create beautiful CSS box shadows.',
    category: 'CSS Tools',
    path: '/box-shadow',
    icon: 'Box'
  },
  {
    id: 'animation-builder',
    name: 'Animation Builder',
    description: 'Create CSS animations without writing keyframes.',
    category: 'CSS Tools',
    path: '/animation-builder',
    icon: 'PlayCircle'
  },
  {
    id: 'html-to-react',
    name: 'HTML to React Converter',
    description: 'Convert HTML code to React or Next.js components.',
    category: 'Code Converters',
    path: '/html-to-react',
    icon: 'Code'
  },
  {
    id: 'css-root-generator',
    name: 'CSS Root Generator',
    description: 'Extract colors from a logo and generate a semantic CSS :root system.',
    category: 'Color & Theme Tools',
    path: '/css-root-generator',
    icon: 'Palette'
  },
  {
    id: 'css-filter',
    name: 'CSS Filter Generator',
    description: 'Generate CSS filter properties visually.',
    category: 'CSS Tools',
    path: '/css-filter',
    icon: 'Wand2'
  },
  {
    id: 'glassmorphism',
    name: 'Glassmorphism',
    description: 'Create modern frosted glass effects.',
    category: 'CSS Tools',
    path: '/glassmorphism',
    icon: 'Droplets'
  },
  {
    id: 'gradient-generator',
    name: 'Gradient Generator',
    description: 'Generate beautiful CSS gradients with live preview.',
    category: 'CSS Tools',
    path: '/gradient-generator',
    icon: 'Palette'
  },
  {
    id: 'mesh-gradient',
    name: 'Gradient Mesh Generator',
    description: 'Create beautiful mesh gradients visually and generate ready-to-use CSS.',
    category: 'CSS Tools',
    path: '/mesh-gradient',
    icon: 'Sparkles'
  },
  {
    id: 'grid-builder',
    name: 'Grid Layout Builder',
    description: 'Visually create CSS Grid layouts.',
    category: 'CSS Tools',
    path: '/grid-builder',
    icon: 'LayoutGrid'
  },
  {
    id: 'clip-path',
    name: 'Clip-Path Generator',
    description: 'Create custom CSS clip-path shapes visually and generate ready-to-use CSS.',
    category: 'CSS Tools',
    path: '/clip-path',
    icon: 'Scissors'
  },
  {
    id: 'device-preview',
    name: 'Device Preview',
    description: 'Preview layouts across multiple device sizes.',
    category: 'Responsive Tools',
    path: '/device-preview',
    icon: 'Smartphone'
  },
  {
    id: 'video-downloader',
    name: 'Video Downloader',
    description: 'Download video files from supported public sources.',
    category: 'Utilities',
    path: '/video-downloader',
    icon: 'Download'
  }
];

export const categories = [
  'CSS Tools',
  'Color & Theme Tools',
  'Responsive Tools',
  'Code Converters',
  'Icon Tools',
  'Utilities'
];
